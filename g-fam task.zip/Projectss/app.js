const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const dbs = require('./models/db'); 
const usermodel = require('./models/user'); 

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'raj123',
    resave: false,
    saveUninitialized: true
}));

// Middleware to check authentication
function isAuth(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Auth routes
app.get('/', (req, res) => res.redirect('/login'));

app.get('/register', (req, res) => res.render('register'));

app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    try {
        const user = new dbs({ username, password: hashed });
        await user.save(); // FIXED: was await dbs.save()
        res.redirect('/login'); // FIXED: was res.render('/login')
    } catch (err) {
        res.send("User already exists or error occurred.");
    }
});

app.get('/login', (req, res) => {res.render('login');});

// ...existing code...

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await dbs.findOne({ username });

    if (user && await bcrypt.compare(password, user.password)) {
        req.session.userId = user._id;
        req.session.username = user.username;
        res.redirect('/index'); // Redirect to /index after login
    } else {
        res.send("Invalid username or password.");
    }
});

// Add this route to render index.ejs after login
app.get('/index', isAuth, (req, res) => {
    res.render('index', { user: { username: req.session.username } });
});

// ...existing code...

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        res.redirect('/login');
    });
});

// Product CRUD routes (protected)
app.get('/read', isAuth, async (req, res) => {
    let data = await usermodel.find();
    res.render('read', { data, user: { username: req.session.username } });
});

app.get('/delete/:id', isAuth, async (req, res) => {
    await usermodel.findOneAndDelete({ _id: req.params.id });
    res.redirect('/read');
});

app.get('/edit/:userid', isAuth, async (req, res) => {
    let data = await usermodel.findOne({ _id: req.params.userid });
    res.render('edit', { data, user: { username: req.session.username } });
});

app.post('/update/:userid', isAuth, async (req, res) => {
    await usermodel.findOneAndUpdate(
        { _id: req.params.userid },
        {
            name: req.body.name,
            description: req.body.description,
            price: req.body.price,
            imageUrl: req.body.imageUrl
        },
        { new: true }
    );
    res.redirect('/read');
});

app.get('/create', isAuth, (req, res) => {
    res.render('create', { user: { username: req.session.username } });
});

app.post('/create', isAuth, async (req, res) => {
    try {
        await usermodel.create({
            name: req.body.name,
            description: req.body.description,
            price: req.body.price,
            imageUrl: req.body.imageUrl
        });
        res.redirect('/read');
    } catch (err) {
        console.log(err);
        res.redirect('/read');
    }
});

// Start server
app.listen(3000, () => console.log("Server running on http://localhost:3000"));